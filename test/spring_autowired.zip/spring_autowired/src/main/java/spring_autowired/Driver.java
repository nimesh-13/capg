package spring_autowired;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Driver {
	
	public static Order loadBookDetails() {
    
    ApplicationContext context = new AnnotationConfigApplicationContext(ApplicationConfig.class);
    Order order = (Order)context.getBean("order");
    return order;

	}
	

	public static void main(String[] args) {
		Order order = Driver.loadBookDetails();
		order.displayOrderDetails();

	}

}
