package spring_autowired;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Order {
	
	@Value("2")
	private int quantity;
	
	@Autowired
	private Book books;
	
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	
	public void displayOrderDetails() {
		
		System.out.println("Book Name:" + books.getName());
		System.out.println("Book Id:" + books.getId());
		System.out.println("Book price:" +books.getPrice());
		
		System.out.println("Quantity:" + quantity);
	}
	
	

}
